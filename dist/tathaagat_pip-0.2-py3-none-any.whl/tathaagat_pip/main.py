def example():
    print("Hello there this is a wip package")