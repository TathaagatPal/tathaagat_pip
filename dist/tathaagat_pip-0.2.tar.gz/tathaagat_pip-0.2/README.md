A python package I made for fun

Not much inside right now, in the future I will add actually cool stuff to this