def example():
    print("asddfasaf")